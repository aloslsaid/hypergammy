from app.scoring.scorer import overall_score

CATS=[{"category_id":"a","group_id":"g"},{"category_id":"b","group_id":"h"}]
WEIGHTS={"groups":{"g":0.7,"h":0.3}}

def test_weighted_score_and_coverage():
    rows=[{"category_id":"a","score":8,"confidence":0.8},{"category_id":"b","score":4,"confidence":0.6}]
    score,conf,cov=overall_score(rows,CATS,WEIGHTS)
    assert score == 6.8
    assert cov == 100.0
    assert conf == 0.74

def test_missing_category_renormalizes():
    rows=[{"category_id":"a","score":8,"confidence":0.8},{"category_id":"b","score":None,"confidence":0}]
    score,conf,cov=overall_score(rows,CATS,WEIGHTS)
    assert score == 8
    assert cov == 70.0

def test_no_valid_categories():
    score,conf,cov=overall_score([{"category_id":"a","score":None,"confidence":0}],CATS,WEIGHTS)
    assert score is None
