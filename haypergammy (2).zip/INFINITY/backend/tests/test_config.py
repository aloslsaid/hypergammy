from app.core.config import validate_weights, CATEGORIES
def test_categories_defined():
    assert len(CATEGORIES) >= 30
    assert len({c["category_id"] for c in CATEGORIES}) == len(CATEGORIES)
def test_weights_valid():
    validate_weights()
