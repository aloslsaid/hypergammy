from app.core.config import CATEGORIES, REFERENCE_DIR
def ensure_reference_dirs():
    for category in CATEGORIES:
        (REFERENCE_DIR / category["category_id"]).mkdir(parents=True, exist_ok=True)
