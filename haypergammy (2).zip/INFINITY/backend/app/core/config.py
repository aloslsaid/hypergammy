from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parents[2]
CONFIG_DIR = BASE_DIR / "config"
REFERENCE_DIR = BASE_DIR / "reference_images"

def load_json(name):
    with (CONFIG_DIR / name).open("r", encoding="utf-8") as f:
        return json.load(f)

CATEGORIES = load_json("categories.json")
WEIGHTS = load_json("weights.json")
SCORING = load_json("scoring.json")

def validate_weights():
    groups = WEIGHTS["groups"]
    total = sum(float(v) for v in groups.values())
    if any(float(v) < 0 for v in groups.values()):
        raise ValueError("Weight values must be non-negative.")
    if abs(total - 1.0) > 1e-6:
        raise ValueError(f"Group weights must sum to 1.0; got {total:.6f}.")
    ids = [c["category_id"] for c in CATEGORIES]
    if len(ids) != len(set(ids)):
        raise ValueError("Category IDs must be unique.")
    for c in CATEGORIES:
        if c["group_id"] not in groups:
            raise ValueError(f"Unknown weight group for {c['category_id']}")
