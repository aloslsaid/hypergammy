import numpy as np

def compare_features(user_features, reference_features, category):
    method = category["comparison_method"]
    keys = category["required_features"]
    if method in {"profile_geometry", "visual_feature"}:
        return None, 0.0, "This category requires a feature/model not currently implemented for this photo."
    if not all(k in user_features and k in reference_features for k in keys):
        return None, 0.0, "Required measurements are unavailable."
    a = np.concatenate([np.asarray(user_features[k], dtype=float).ravel() for k in keys])
    b = np.concatenate([np.asarray(reference_features[k], dtype=float).ravel() for k in keys])
    if a.shape != b.shape or not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
        return None, 0.0, "Reference and user feature dimensions do not match."
    # Normalize by reference magnitude with a floor; this is an experimental distance.
    scale = np.maximum(np.abs(b), 0.08)
    distance = float(np.mean(np.abs(a-b) / scale))
    score = float(np.clip(10.0 * np.exp(-distance / float(category.get("score_scale", 0.12))), 0, 10))
    return round(score, 2), round(distance, 5), "Experimental reference similarity; not scientifically calibrated."

def overall_score(results, categories, weights):
    by_id = {c["category_id"]: c for c in categories}
    valid = [r for r in results if r.get("score") is not None and r.get("confidence", 0) > 0]
    if not valid:
        return None, 0.0, 0
    # Divide each group weight across every configured category in that group.
    # This prevents groups with more categories from silently dominating the result.
    group_counts = {}
    for category in categories:
        group = category["group_id"]
        group_counts[group] = group_counts.get(group, 0) + 1
    raw_weights = [
        float(weights["groups"][by_id[r["category_id"]]["group_id"]]) /
        group_counts[by_id[r["category_id"]]["group_id"]]
        for r in valid
    ]
    denom = sum(raw_weights)
    if denom <= 0: return None, 0.0, 0
    score = sum(r["score"] * w for r,w in zip(valid,raw_weights)) / denom
    coverage = min(1.0, denom)
    conf = sum(r["confidence"]*w for r,w in zip(valid,raw_weights)) / denom
    return round(score,2), round(conf,2), round(coverage*100,1)
