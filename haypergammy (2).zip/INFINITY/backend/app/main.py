from pathlib import Path
from typing import Optional
import json
import os
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import CATEGORIES, WEIGHTS, SCORING, validate_weights, REFERENCE_DIR
from app.analysis.engine import FaceEngine
from app.scoring.scorer import compare_features, overall_score
from app.services.reference_service import list_references, load_reference_features, save_reference

validate_weights()
app=FastAPI(title="INFINITY API", version="1.0.0", description="Category-specific facial reference comparison.")
cors_origins = [x.strip() for x in os.getenv("INFINITY_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=cors_origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
engine=FaceEngine()

@app.on_event("startup")
async def startup():
    REFERENCE_DIR.mkdir(parents=True,exist_ok=True)

@app.get("/health")
def health():
    return {"status":"ok","face_model_ready":engine.ready,"device":"CPU","category_count":len(CATEGORIES)}

@app.get("/categories")
def categories():
    return {"categories":CATEGORIES,"weight_groups":WEIGHTS["groups"],"scoring_status":SCORING["calibration_status"]}

@app.get("/references")
def references():
    return {"references":list_references(CATEGORIES)}

@app.put("/references/{category_id}")
async def upload_reference(category_id: str, file: UploadFile=File(...), source: str="User-provided / permission confirmed", view: str="frontal"):
    category=next((c for c in CATEGORIES if c["category_id"]==category_id),None)
    if not category: raise HTTPException(404,"Unknown category.")
    data=await file.read()
    if len(data)>10*1024*1024: raise HTTPException(413,"Reference image exceeds 10 MB.")
    try:
        save_reference(category_id,data,{"source":source,"permission_confirmed":True,"capture_view":view},engine)
    except RuntimeError as e: raise HTTPException(503,str(e))
    except Exception as e: raise HTTPException(400,str(e))
    return {"status":"saved","category_id":category_id}

@app.post("/analyze")
async def analyze(file: UploadFile=File(...)):
    ext=Path(file.filename or "").suffix.lower()
    if ext not in {".jpg",".jpeg",".png",".webp"}: raise HTTPException(415,"Upload a JPG, PNG, or WEBP image.")
    data=await file.read()
    if len(data)>10*1024*1024: raise HTTPException(413,"Image exceeds 10 MB.")
    try: result=engine.analyze(data)
    except RuntimeError as e: raise HTTPException(503,str(e))
    except ValueError as e: raise HTTPException(422,str(e))
    rows=[]
    for c in CATEGORIES:
        ref=load_reference_features(c["category_id"],engine)
        if ref is None:
            rows.append({"category_id":c["category_id"],"name":c["display_name"],"score":None,"confidence":0,
                         "weight_group":c["group_id"],"status":"reference_missing","explanation":"Add a dedicated reference image for this category."})
            continue
        score,distance,message=compare_features(result["features"],ref,c)
        if score is None:
            rows.append({"category_id":c["category_id"],"name":c["display_name"],"score":None,"confidence":0,
                         "weight_group":c["group_id"],"status":"not_assessable","explanation":message})
        else:
            rows.append({"category_id":c["category_id"],"name":c["display_name"],"score":score,
                         "confidence":result["confidence"],"distance":distance,"weight_group":c["group_id"],
                         "status":"experimental","explanation":message})
    total,confidence,coverage=overall_score(rows,CATEGORIES,WEIGHTS)
    return {"product":"INFINITY","score_label":"Reference Match Score","overall_score":total,
            "overall_confidence":confidence,"coverage_percent":coverage,
            "analyzed_categories":sum(r["score"] is not None for r in rows),
            "unavailable_categories":sum(r["score"] is None for r in rows),
            "categories":rows,"image_quality":result["quality"],
            "limitations":["Scores indicate similarity to your configured category references, not objective attractiveness.",
                           "Current scoring is experimental and has not been scientifically calibrated.",
                           "Single frontal images cannot reliably measure all 34 categories."]}
