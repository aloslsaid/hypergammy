from pydantic import BaseModel
from typing import Any

class HealthResponse(BaseModel):
    status: str
    face_model_ready: bool
    device: str
    category_count: int

