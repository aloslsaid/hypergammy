import json
from pathlib import Path
import cv2
import numpy as np
from app.core.config import REFERENCE_DIR

def reference_path(category_id):
    return REFERENCE_DIR / category_id / "reference.jpg"

def list_references(categories):
    out=[]
    for c in categories:
        p=reference_path(c["category_id"])
        meta=p.parent/"metadata.json"
        exists=p.exists() and meta.exists()
        data={}
        if meta.exists():
            try: data=json.loads(meta.read_text(encoding="utf-8"))
            except Exception: data={}
        out.append({"category_id":c["category_id"],"display_name":c["display_name"],
                    "available":exists,"status":"ready" if exists else "missing",
                    "metadata":data if exists else None})
    return out

def load_reference_features(category_id, engine):
    p=reference_path(category_id)
    if not p.exists(): return None
    data=p.read_bytes()
    try: return engine.analyze(data)["features"]
    except Exception: return None

def save_reference(category_id, image_bytes, metadata, engine):
    # Validate by running same image pipeline before accepting the reference.
    engine.analyze(image_bytes)
    folder=REFERENCE_DIR/category_id
    folder.mkdir(parents=True,exist_ok=True)
    p=folder/"reference.jpg"
    arr=np.frombuffer(image_bytes,np.uint8)
    img=cv2.imdecode(arr,cv2.IMREAD_COLOR)
    if img is None: raise ValueError("Invalid reference image.")
    ok,encoded=cv2.imencode(".jpg",img,[int(cv2.IMWRITE_JPEG_QUALITY),95])
    if not ok: raise ValueError("Could not encode reference image.")
    p.write_bytes(encoded.tobytes())
    meta={**metadata,"category_id":category_id,"file":"reference.jpg","note":"Reference match is not a universal ideal."}
    (folder/"metadata.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
