# INFINITY — Facial Reference Analysis

INFINITY is a category-by-category facial reference comparison application. Each supported category has its own reference image slot and comparison configuration. The frontend is a React/Vite app that can be imported into Lovable or deployed independently; the computer-vision API is a separate FastAPI service.

## Important
This is an experimental reference similarity tool, not a scientifically validated attractiveness measurement. Scores indicate similarity to the selected references only. The initial reference database is intentionally empty: **you must supply a separate, permission-cleared reference image for each category**. Missing references do not produce scores.

The current engine implements a first-pass MediaPipe landmark feature pipeline for supported frontal measurements. Categories requiring profile geometry or visual texture models remain unavailable. Do not describe all 34 categories as fully implemented.

## Project layout
- `frontend/`: Lovable-friendly React + TypeScript + Vite application.
- `backend/`: FastAPI API and MediaPipe landmark engine.
- `backend/config/`: category catalog, group weights, scoring settings.
- `backend/reference_images/`: one dedicated reference folder per category.
- `docs/`: category and limitation notes.

## Run locally (Windows)
### 1. Backend
Install Python 3.11, then:
```powershell
cd backend
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
API docs: http://127.0.0.1:8000/docs

### 2. Frontend
Open another terminal:
```powershell
cd frontend
npm install
copy .env.example .env
npm run dev
```
Open http://localhost:5173. Set `VITE_API_URL` to your deployed API URL if the backend is hosted elsewhere.

## Add references
The API provides `PUT /references/{category_id}`. Upload a JPG/PNG/WEBP image in multipart field `file`. You can also add:
`backend/reference_images/{category_id}/reference.jpg`
and a `metadata.json` file alongside it.
Only use photographs you own or have explicit permission to use. Keep capture view consistent with the category's required view. A reference image is not an ideal or universal standard.

## Change category weights
Edit `backend/config/weights.json`. The group weights must be non-negative and sum to 1.0. Categories map to one group each to avoid accidental double-counting. Restart the backend after changes.

## Tests
```powershell
cd backend
$env:PYTHONPATH="."
pytest -q
```
Frontend production build:
```powershell
cd frontend
npm run build
```

## Deploy / use with Lovable
Lovable is primarily used to build and sync a web frontend with GitHub. This project contains a standard Vite React app in `frontend/`. For a clean import:
1. Create a GitHub repository.
2. Upload the contents of `frontend/` to the repository root (not the outer INFINITY folder).
3. Import/connect that repository in Lovable.
4. Keep the backend deployed separately on a Python-capable host (for example Render, Railway, or a VPS).
5. Set the frontend environment variable `VITE_API_URL` to the public backend URL in the deployment environment.
6. Configure backend CORS to include the deployed frontend domain before production use.

Lovable cannot run the MediaPipe Python backend as part of the standard React frontend. Do not expect the ZIP to make the API run inside Lovable by itself.

## Privacy and production checklist
- The default API processes images in memory and does not intentionally save user uploads.
- Reference images are saved locally by the reference upload endpoint.
- Add authentication/admin protection to reference upload before exposing the API publicly.
- Add rate limiting, HTTPS, monitoring, retention controls, and deployment-specific CORS.
- Review model/library licenses and applicable privacy requirements before public launch.
