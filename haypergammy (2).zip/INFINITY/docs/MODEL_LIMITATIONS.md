# Model limitations

- MediaPipe Face Mesh landmarks are 2D/estimated 3D coordinates, not a clinical anthropometric scan.
- Camera perspective, focal length, head pose, lighting, makeup, facial hair, and expression affect measurements.
- A frontal image cannot reliably establish forward chin projection or other true depth properties.
- Skin appearance and eyebrow density need dedicated visual models and controlled capture conditions.
- A reference similarity score depends on the chosen reference and score scale.
- The default scoring mapping has not been calibrated against a representative dataset or validated by independent research.
- Unit tests validate software logic, not scientific validity or population-level accuracy.
