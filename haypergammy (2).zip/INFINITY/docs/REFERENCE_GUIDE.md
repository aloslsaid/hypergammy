# Reference image guide

Each category has a folder under `backend/reference_images/` and expects `reference.jpg` plus `metadata.json`.

Use a high-resolution image you own or have permission to use. Prefer frontal, neutral-expression, evenly lit photos for frontal categories. Do not use a profile reference for a frontal comparison. Do not label any reference as objectively ideal.

The API can save a reference using `PUT /references/{category_id}`. The upload is checked by the same face-analysis engine before it is saved. The reference database is empty in the delivered project, so the app will correctly report missing references until configured.
