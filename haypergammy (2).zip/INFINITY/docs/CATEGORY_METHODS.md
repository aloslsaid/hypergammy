# Category methods and implementation status

All 34 category definitions are in `backend/config/categories.json`. Every category has a dedicated reference path. The backend only emits a score if a reference exists and all configured features are available.

The current engine derives normalized 2D landmark ratios from MediaPipe Face Mesh. Category-specific feature lists and comparison method labels are configured per category. The first-pass scoring map is exponential normalized feature distance and is **experimental / uncalibrated**. It is not an objective attractiveness score.

Categories requiring profile geometry or unavailable visual texture features return no score. Projection, ear proportions, eyebrow density, and skin appearance are not reliably implemented in the current single-frontal-image engine.
